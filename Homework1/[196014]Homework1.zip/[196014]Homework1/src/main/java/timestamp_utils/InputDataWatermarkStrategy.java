package timestamp_utils;

import model.pojo.InputData;
import org.apache.flink.api.common.eventtime.*;

public class InputDataWatermarkStrategy implements WatermarkStrategy<InputData> {
    @Override
    public TimestampAssigner<InputData> createTimestampAssigner(TimestampAssignerSupplier.Context context) {
        return (element, recordTimestamp) -> element.getTimestamp();
    }

    @Override
    public WatermarkGenerator<InputData> createWatermarkGenerator(WatermarkGeneratorSupplier.Context context) {
        return new WatermarkGenerator<InputData>() {
            @Override
            public void onEvent(InputData event, long eventTimestamp, WatermarkOutput output) {
                output.emitWatermark(new Watermark(event.getTimestamp()));
            }

            @Override
            public void onPeriodicEmit(WatermarkOutput output) {
                output.emitWatermark(new Watermark(System.currentTimeMillis()));
            }
        };
    }
}
