package source.schemas;

import model.pojo.OutputData;
import org.apache.flink.api.common.serialization.SerializationSchema;

public class OutputDataResultSerializationSchema implements SerializationSchema<OutputData> {
    @Override
    public byte[] serialize(OutputData element) {
        return element.toString().getBytes();
    }
}
