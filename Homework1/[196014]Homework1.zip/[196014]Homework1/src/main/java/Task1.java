import com.google.gson.Gson;
import model.pojo.InputData;
import model.pojo.OutputData;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import source.factories.SinkFactory;
import source.factories.SourceDataStreamFactory;
import timestamp_utils.InputDataWatermarkStrategy;

import java.util.stream.StreamSupport;

public class Task1 {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        ParameterTool parameterTool = ParameterTool.fromArgs(args);

        DataStream<InputData> inputDataStream = SourceDataStreamFactory.getStream(parameterTool, env)
                .map(obj -> obj.findValue("value"))
                .map(value -> new Gson().fromJson(String.valueOf(value), InputData.class));

        //inputDataStream.print();

        SingleOutputStreamOperator<OutputData> result = inputDataStream
                .assignTimestampsAndWatermarks(new InputDataWatermarkStrategy())
                .keyBy(InputData::getKey)
                .window(SlidingEventTimeWindows.of(Time.seconds(10), Time.seconds(2)))
                .apply(new WindowFunction<InputData, OutputData, String, TimeWindow>() {
                           @Override
                           public void apply(String key, TimeWindow timeWindow, Iterable<InputData> iterable,
                                             Collector<OutputData> collector) throws Exception {
                               int sum = (int) StreamSupport.stream(iterable.spliterator(), false).count();
                               OutputData outputData = new OutputData(key, sum);
                               collector.collect(outputData);
                           }
                       }
                );

        result.print();

        //Send to Kafka Consumer
        result.addSink(SinkFactory.getSink1(parameterTool));
        env.execute(Task1.class.toString());
    }
}
