package model.pojo;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.Serializable;
import java.util.Objects;

import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class InputData implements Serializable{
    @SerializedName("key")
    @Expose
    private String key;
    @SerializedName("value")
    @Expose
    private Integer value;
    @SerializedName("timestamp")
    @Expose
    private Long timestamp;
    private final static long serialVersionUID = 4961563406871631892L;

    public InputData() {
    }

    public InputData(String key, Integer value, Long timestamp) {
        super();
        this.key = key;
        this.value = value;
        this.timestamp = timestamp;
    }

    public String getKey() {
        return key;
    }

    public Integer getValue() {
        return value;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return  "Key: " + key + " Value: " + value + " Timestamp: " + timestamp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InputData inputData = (InputData) o;
        return Objects.equals(key, inputData.key) && Objects.equals(value, inputData.value) && Objects.equals(timestamp, inputData.timestamp);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key, value, timestamp);
    }
}
