package model.pojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class OutputData {

    @SerializedName("key")
    @Expose
    private String key;
    @SerializedName("total")
    @Expose
    private Integer total;

    public OutputData(String key, Integer total) {
        this.key = key;
        this.total = total;
    }

    public String getKey() {
        return key;
    }

    public Integer getTotal() {
        return total;
    }

    @Override
    public String toString() {
        return "{\"Key\":\"" + key + "\", \"Total\":" + total + "}";
    }
}